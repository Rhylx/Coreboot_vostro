
Lint files for PC-Lint (FlexLint) by Gimpel Software, Inc.

These are the configuration and option files used to lint the 
ACPI-CA software.

lset.bat    - adds lint directory to the command line search path
lint.bat    - lint batch file for 32 and 64 bit lint
std16.lnt   - 16-bit options
std32.lnt   - 32-bit options
std64.lnt   - 64-bit options
options.lnt - common options
others      - windows/dos compiler option files

